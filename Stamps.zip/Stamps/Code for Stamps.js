//Entered --------------------------------
// --StampName: #J3S9HGlVs9zZC8AF_TsTQB
// Entered On
if (event.source.forReal && (event.source.stampName == "#J3S9HGlVs9zZC8AF_TsTQB"))
{
    event.value = (new Date()).toString();
    AFDate_FormatEx("dd/mm/yyyy");
}
else {
    event.value = "";
}
// Entered By
if (event.source.forReal && (event.source.stampName == "#J3S9HGlVs9zZC8AF_TsTQB"))
{
	var nameParts = identity.loginName.split(".");
	event.value = nameParts[0].substr(0, 1).toUpperCase() + nameParts[0].substr(1) + " " + nameParts[1].substr(0, 1).toUpperCase() + nameParts[1].substr(1);
}
else {
    event.value = "";
}

// Paid --------------------------------
// StampName: #7qgK8d8T2A8TPXrh3L9neA
//Paid At
function formatAMPM(date) {
  var hours = date.getHours();
  var minutes = date.getMinutes();
  var ampm = hours >= 12 ? 'pm' : 'am';
  hours = hours % 12;
  hours = hours ? hours : 12; // the hour '0' should be '12'
  minutes = minutes < 10 ? '0'+minutes : minutes;
  var strTime = hours + ':' + minutes + ' ' + ampm;
  return strTime;
}
//Paid 
if (event.source.forReal && (event.source.stampName == "#7qgK8d8T2A8TPXrh3L9neA"))
{
	var time = formatAMPM(new Date);
	event.value = (new Date()).toString();
	AFDate_FormatEx("dd/mm/yyyy");
	event.value = time + ", " + event.value;
}
else {
    event.value = "";
}

// Paid By
if (event.source.forReal && (event.source.stampName == "#7qgK8d8T2A8TPXrh3L9neA"))
{
	var nameParts = identity.loginName.split(".");
	event.value = nameParts[0].substr(0, 1).toUpperCase() + nameParts[0].substr(1) + " " + nameParts[1].substr(0, 1).toUpperCase() + nameParts[1].substr(1);
}
else {
    event.value = "";
}
// Recieved -------------------------
// StampName: #WeJplA4l8tPy1wXUTiURWC
// Payment Approved
var cAsk = "Enter a value";
var cTitle = "Payment Approved";
//to get the stamps internal name, run this script "event.value = event.source.stampName;"
if (event.source.forReal && (event.source.stampName == "#WeJplA4l8tPy1wXUTiURWC"))
{
    var cMsg = app.response(cAsk, cTitle);
    event.value = cMsg;
    event.source.source.info.DocumentState = cMsg;
}
else {
    event.value = event.source.stampName;
}

//General Ledger Code
var cAsk = "Enter a value";
var cTitle = "General Ledger Code";
//to get the stamps internal name, run this script "event.value = event.source.stampName;"
if (event.source.forReal && (event.source.stampName == "#WeJplA4l8tPy1wXUTiURWC"))
{
    var cMsg = app.response(cAsk, cTitle);
    event.value = cMsg;
    event.source.source.info.DocumentState = cMsg;
}
else {
    event.value = "";
}

//Date
if (event.source.forReal && (event.source.stampName == "#WeJplA4l8tPy1wXUTiURWC"))
{
	event.value = (new Date()).toString();
    AFDate_FormatEx("dd/mm/yyyy");
}
else {
    event.value = "";
}