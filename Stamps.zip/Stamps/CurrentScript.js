var cAsk = "Enter a value";
var cTitle = "This is the title";
//to get the stamps internal name, run this script "event.value = event.source.stampName;"
if (event.source.forReal && (event.source.stampName == "#"))
{
    var cMsg = app.response(cAsk, cTitle);
    event.value = cMsg;
    event.source.source.info.DocumentState = cMsg;
}


var cAsk = "Enter a value";
var cTitle = "";
//to get the stamps internal name, run this script "event.value = event.source.stampName;"
if (event.source.forReal && (event.source.stampName == "#h9OvAAfN8RkyccVel1Je9C"))
{
    var cMsg = app.response(cAsk, cTitle);
    event.value = cMsg;
    event.source.source.info.DocumentState = cMsg;
}

//Name and date javascript
event.value = (new Date()).toString();
AFDate_FormatEx("dd mmm yyyy");
//event.value = "By " + ((!identity.name || identity.loginName != (event.source.source || this).Collab.user) ? (event.source.source || this).Collab.user : identity.name)
// + " at " + event.value;
//event.value = identity.loginName.substr(0, 1).toUpperCase() + identity.loginName.substr(1);

var nameParts = strings.map(function(s) {
		return s.split(".").slice(0,1)
});
event.value = nameParts[0].substr(0, 1).toUpperCase() + nameParts[0].substr(1) + " " + nameParts[1].substr(0, 1).toUpperCase() + nameParts[1].substr(1)










//new
var cAsk = "Enter a value";
var cTitle = "Goods Received";
//to get the stamps internal name, run this script "event.value = event.source.stampName;"
if (event.source.forReal && (event.source.stampName == "#da84L5Lxne2MQGH-p-Fw4D"))
{
    var cMsg = app.response(cAsk, cTitle);
    event.value = cMsg;
    event.source.source.info.DocumentState = cMsg;
}
//--------------------------------------------
var cAsk = "Enter a value";
var cTitle = "Prices Checked";
//to get the stamps internal name, run this script "event.value = event.source.stampName;"
if (event.source.forReal && (event.source.stampName == "#da84L5Lxne2MQGH-p-Fw4D"))
{
    var cMsg = app.response(cAsk, cTitle);
    event.value = cMsg;
    event.source.source.info.DocumentState = cMsg;
}
//--------------------------------------------
var cAsk = "Enter a value";
var cTitle = "Payment Approved";
//to get the stamps internal name, run this script "event.value = event.source.stampName;"
if (event.source.forReal && (event.source.stampName == "#da84L5Lxne2MQGH-p-Fw4D"))
{
    var cMsg = app.response(cAsk, cTitle);
    event.value = cMsg;
    event.source.source.info.DocumentState = cMsg;
}
//--------------------------------------------
var cAsk = "Enter a value";
var cTitle = "General Ledger Code";
//to get the stamps internal name, run this script "event.value = event.source.stampName;"
if (event.source.forReal && (event.source.stampName == "#da84L5Lxne2MQGH-p-Fw4D"))
{
    var cMsg = app.response(cAsk, cTitle);
    event.value = cMsg;
    event.source.source.info.DocumentState = cMsg;
}
//--------------------------------------------
var cAsk = "Enter a value";
var cTitle = "Cheque number";
//to get the stamps internal name, run this script "event.value = event.source.stampName;"
if (event.source.forReal && (event.source.stampName == "#da84L5Lxne2MQGH-p-Fw4D"))
{
    var cMsg = app.response(cAsk, cTitle);
    event.value = cMsg;
    event.source.source.info.DocumentState = cMsg;
}
//--------------------------------------------
if (event.source.forReal && (event.source.stampName == "#da84L5Lxne2MQGH-p-Fw4D"))
{
    event.value = (new Date()).toString();
    AFDate_FormatEx("dd/MM/yyyy");
}
//--------------------------------------------
var cAsk = "Enter a value";
var cTitle = "Payrun number";
//to get the stamps internal name, run this script "event.value = event.source.stampName;"
if (event.source.forReal && (event.source.stampName == "#da84L5Lxne2MQGH-p-Fw4D"))
{
    var cMsg = app.response(cAsk, cTitle);
    event.value = cMsg;
    event.source.source.info.DocumentState = cMsg;
}
//--------------------------------------------
if (event.source.forReal && (event.source.stampName == "#da84L5Lxne2MQGH-p-Fw4D"))
{
    event.value = (new Date()).toString();
    AFDate_FormatEx("dd/MM/yyyy");
}
//--------------------------------------------